#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>     
#include <sys/wait.h>
#include <string.h> 
#include <sys/ipc.h>    // shared memory functionality
#include <sys/shm.h>    // shm_open
#include <sys/types.h>  // ftruncate
#include <sys/stat.h>
#include <sys/mman.h>   // mmap
#include <fcntl.h>      // O_CREAT, O_RDWR, etc




int total(char* s){
    int num = atoi(s);
    int sum = 0;

    // count up to 5, adding all the digits into sum
    for(int i = 1; i <= num; i++){
        sum += i;
    }

    printf("Total[%d] : Sum = %d\n", getpid(), sum);
    return sum;
    
}


int main(int argc, char *argv[]){
    int num = total(argv[1]);
    int size = 32;
    // open and map the memory segment
    int shm_fd = shm_open(argv[2], O_RDWR, 0666);
    void * shmPtr = mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    // write the num returned by total to the memory segment
    sprintf(shmPtr, "%d", num);
    //shm_unlink(argv[2]);
    return 1;

}

