Instructions for hw3:

To compile:
    make

to clean directory:
    make clean

to run program:
    ./Starter filename 
        where filename is the name of the file being passed to the program



Questions:

1. pipe() is the function used to create a pipe, must create a 2 element array to pass it. 0 denotes the read end and 1 denotes the write end

2. mmap() is used to map files or devices into memory

3. shm_open() is used to open a shared memory object
    it returns a file descriptor