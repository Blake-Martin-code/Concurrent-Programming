#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>     
#include <sys/wait.h>
#include <string.h> 

int main(int argc, char *argv[]){
    int sum = 0;
    int pipe = atoi(argv[2]);

    FILE *file_ptr;
    char* file_name = argv[1];
    // open file for reading only
    file_ptr = fopen(file_name, "r");
    // check to make sure it was opened properly
    if (!file_ptr){
        printf("Error: File failed to open.\n");
        exit(0);
    }    

    char line[255];
    // loop through contents of the file and add each number together for the sum
    while(fgets(line, 5, file_ptr) != NULL){
        int num = atoi(line);
        sum += num;

    }

    // close the file since all the contents have been read
    fclose(file_ptr);
    // write the sum to the write end of the pipe
    char message[sizeof(sum)];
    sprintf(message, "%d", sum);
    write(pipe, message, sizeof(message));
    close(pipe);
    // control will now be returned to the parent process
    return 1;
}