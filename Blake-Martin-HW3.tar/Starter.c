#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>     
#include <sys/wait.h>
#include <string.h> 
#include <sys/ipc.h>    // shared memory functionality
#include <sys/shm.h>    // shm_open
#include <sys/types.h>  // ftruncate
#include <sys/stat.h>
#include <sys/mman.h>   // mmap
#include <fcntl.h>      // O_CREAT, O_RDWR, etc


#define BUFFER_SIZE 25
#define READ_END 0
#define WRITE_END 1

int main(int argc, char *argv[]){
    //char write_msg[BUFFER_SIZE];
    char read_msg[BUFFER_SIZE];
    // make sure that there is only one argument passed
    // if argc is anything but 2 throw an error
    if (argc < 2){
        printf("Error: Too few arguments passed.\n");
        exit(0);
    }
    if(argc > 2){
        printf("Error: Too many arguments passed.\n");
        exit(0);
    }

    pid_t pid;
    // create the pipe
    int fd[2];
    // create the array that is going to hold the sum of numbers
    int number[1];

    //create the pipe and check that it succeeded
    if (pipe(fd) == -1){
        fprintf(stderr, "Pipe failed");
        return -1;
    }

    // fork a child process
    pid = fork();

    //check to see if the fork failed
    if (pid < 0){
        fprintf(stderr, "Fork failed");
        return 1;
    }
    // parent process
    if (pid > 0){
        // close the write end of the pipe
        close(fd[WRITE_END]);
        // this wait messes up the order of the output
        wait(NULL);
        // read from the pipe and insert the sum into the number array
        read(fd[READ_END], read_msg, BUFFER_SIZE);
        number[0] = atoi(read_msg);
        // print the contents read from the read end pipe
        printf("Starter[%d]: contents read from the read end pipe: %d\n", getppid(), number[0]);

    }
    // child process
    else{
        //close read end
        close(fd[READ_END]);
        // execute the CharacterReader program with the arguments
        // name of the file and the pipe to read and write to
        char *filename = argv[1];
        char pipe_val[sizeof(fd[WRITE_END])];
        sprintf(pipe_val, "%d", fd[WRITE_END]);
        execlp("./CharacterReader.o", "./CharacterReader.o", filename, pipe_val, NULL);

    }





    // create share memory segments for prime total and fib
    // SHM_name of file fibb/prime/total

    char SHM_Fibb[] = "SHM_Fibb";
    char SHM_Prime[] = "SHM_Prime";
    char SHM_Total[] = "SHM_Total";

    int shm_fd1 = shm_open(SHM_Fibb, O_CREAT | O_RDWR, 0666);
    int shm_fd2 = shm_open(SHM_Prime, O_CREAT | O_RDWR, 0666);
    int shm_fd3 = shm_open(SHM_Total, O_CREAT | O_RDWR, 0666);

    int size = 32;

    ftruncate(shm_fd1, size);
    ftruncate(shm_fd2, size);
    ftruncate(shm_fd3, size);
    
    // map all 3 of the memory segments
    void * shmPtr1 = mmap(0, size, PROT_WRITE | PROT_READ, MAP_SHARED, shm_fd1, 0);
    printf("Starter[%d]: Created shared memory \"SHM_Fibb\" with FD: %d\n", getppid(), shm_fd1);
    void * shmPtr2 = mmap(0, size, PROT_WRITE | PROT_READ, MAP_SHARED, shm_fd2, 0);
    printf("Starter[%d]: Created shared memory \"SHM_Prime\" with FD: %d\n", getppid(), shm_fd2);
    void * shmPtr3 = mmap(0, size, PROT_WRITE | PROT_READ, MAP_SHARED, shm_fd3, 0);
    printf("Starter[%d]: Created shared memory \"SHM_Total\" with FD: %d\n", getppid(), shm_fd3);


    // Begin the forking of each 3 programs

    int num_process = 3;
    pid_t * pids = calloc(size, sizeof(pid_t));
    // the sum of the numbers in the file
    char sum_num[sizeof(number[0])];
    sprintf(sum_num, "%d", number[0]);

    // fork the child processes
    for(int i = 0; i < num_process; ++i){
        pids[i] = fork();
        if((i == 0) & (pids[i] == 0)){// execute the total program
            execlp("./Total.o", "./Total.o", sum_num, SHM_Total, NULL);
        }
        if((i == 1) & (pids[i] == 0)){// execute the prime program
            execlp("./Prime.o", "./Prime.o", sum_num, SHM_Prime, NULL);
        }
        if((i == 2) & (pids[i] == 0)){// execute the fibb program
            execlp("./Fibb.o", "./Fibb.o", sum_num, SHM_Fibb, NULL);
        }
    }

    // wait for the child process
    for(int i = 0; i < num_process; ++i){
        waitpid(pids[i], NULL, 0);
    }


    // print out the last number which is returned by each program
    printf("Starter[%d]: Fibb last number: %s\n", getppid(), (char *)shmPtr1);
    printf("Starter[%d]: Prime last number: %s\n", getppid(), (char *)shmPtr2);
    printf("Starter[%d]: Total last number: %s\n", getppid(), (char *)shmPtr3);

    //free the allocated pids memory
    free(pids);
    //Unlink all the memory segments
    shm_unlink(SHM_Fibb);
    shm_unlink(SHM_Prime);
    shm_unlink(SHM_Total);



    return 1;
}