#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <sys/types.h>
#include <unistd.h>     
#include <sys/wait.h>
#include <string.h> 
#include <sys/ipc.h>    // shared memory functionality
#include <sys/shm.h>    // shm_open
#include <sys/types.h>  // ftruncate
#include <sys/stat.h>
#include <sys/mman.h>   // mmap
#include <fcntl.h>      // O_CREAT, O_RDWR, etc

int prime(char* s){
    int n = atoi(s);
    printf("Prime[%d] : First %d prime numbers are:\n", getpid(), n);
    int  i,p,count,flag;
    p=2;
    i=1; 

    // While the number of prime numbers found is less than 
    // or equal to the number of prime numbers wanted
    while(i<=n){
        flag=1;

        // starting at 2(first prime number) increment count looking for 
        // the next prime number
        for(count=2;count<=p-1;count++){
            // if p is not prime change flag to 0 and break
            if(p%count==0){
             flag=0;
             break;  
            }  
        }
        // if p is prime then print out the number and increment i so we know
        // that we found the next prime number. 
            if(flag==1){
                printf("%d, ",p) ;
             i++;
            }
        // increment p which is the next number to be tested if it is prime
        p++;
    }

    printf("\n");
    return p-1;
}


int main(int argc, char *argv[]){
    int num = prime(argv[1]);
    int size = 32;
    // open and map the memory segment
    int shm_fd = shm_open(argv[2], O_RDWR, 0666);
    void * shmPtr = mmap(0, size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    // write the num returned by prime to the memory segment
    sprintf(shmPtr, "%d", num);
    //shm_unlink(argv[2]);
    return 1;
    
}